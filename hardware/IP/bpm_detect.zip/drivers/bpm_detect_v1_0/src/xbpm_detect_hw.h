// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// CTRL
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of regs_0
//        bit 31~0 - regs_0[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of regs_1
//        bit 31~0 - regs_1[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of regs_2
//        bit 31~0 - regs_2[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of regs_3
//        bit 31~0 - regs_3[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of regs_4
//        bit 31~0 - regs_4[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of regs_5
//        bit 31~0 - regs_5[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of regs_6
//        bit 31~0 - regs_6[31:0] (Read)
// 0x44 : Control signal of regs_6
//        bit 0  - regs_6_ap_vld (Read/COR)
//        others - reserved
// 0x50 : Data signal of regs_7
//        bit 31~0 - regs_7[31:0] (Read)
// 0x54 : Control signal of regs_7
//        bit 0  - regs_7_ap_vld (Read/COR)
//        others - reserved
// 0x60 : Data signal of regs_8
//        bit 31~0 - regs_8[31:0] (Read)
// 0x64 : Control signal of regs_8
//        bit 0  - regs_8_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XBPM_DETECT_CTRL_ADDR_REGS_0_DATA 0x10
#define XBPM_DETECT_CTRL_BITS_REGS_0_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_1_DATA 0x18
#define XBPM_DETECT_CTRL_BITS_REGS_1_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_2_DATA 0x20
#define XBPM_DETECT_CTRL_BITS_REGS_2_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_3_DATA 0x28
#define XBPM_DETECT_CTRL_BITS_REGS_3_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_4_DATA 0x30
#define XBPM_DETECT_CTRL_BITS_REGS_4_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_5_DATA 0x38
#define XBPM_DETECT_CTRL_BITS_REGS_5_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_6_DATA 0x40
#define XBPM_DETECT_CTRL_BITS_REGS_6_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_6_CTRL 0x44
#define XBPM_DETECT_CTRL_ADDR_REGS_7_DATA 0x50
#define XBPM_DETECT_CTRL_BITS_REGS_7_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_7_CTRL 0x54
#define XBPM_DETECT_CTRL_ADDR_REGS_8_DATA 0x60
#define XBPM_DETECT_CTRL_BITS_REGS_8_DATA 32
#define XBPM_DETECT_CTRL_ADDR_REGS_8_CTRL 0x64

