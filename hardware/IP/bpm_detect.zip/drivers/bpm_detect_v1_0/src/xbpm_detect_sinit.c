// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xbpm_detect.h"

extern XBpm_detect_Config XBpm_detect_ConfigTable[];

#ifdef SDT
XBpm_detect_Config *XBpm_detect_LookupConfig(UINTPTR BaseAddress) {
	XBpm_detect_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XBpm_detect_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XBpm_detect_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XBpm_detect_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBpm_detect_Initialize(XBpm_detect *InstancePtr, UINTPTR BaseAddress) {
	XBpm_detect_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBpm_detect_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBpm_detect_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XBpm_detect_Config *XBpm_detect_LookupConfig(u16 DeviceId) {
	XBpm_detect_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XBPM_DETECT_NUM_INSTANCES; Index++) {
		if (XBpm_detect_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XBpm_detect_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBpm_detect_Initialize(XBpm_detect *InstancePtr, u16 DeviceId) {
	XBpm_detect_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBpm_detect_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBpm_detect_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

