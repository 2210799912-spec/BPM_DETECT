// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xbpm_detect.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XBpm_detect_CfgInitialize(XBpm_detect *InstancePtr, XBpm_detect_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XBpm_detect_Set_regs_0(XBpm_detect *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBpm_detect_WriteReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_0_DATA, Data);
}

u32 XBpm_detect_Get_regs_0(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_0_DATA);
    return Data;
}

void XBpm_detect_Set_regs_1(XBpm_detect *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBpm_detect_WriteReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_1_DATA, Data);
}

u32 XBpm_detect_Get_regs_1(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_1_DATA);
    return Data;
}

void XBpm_detect_Set_regs_2(XBpm_detect *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBpm_detect_WriteReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_2_DATA, Data);
}

u32 XBpm_detect_Get_regs_2(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_2_DATA);
    return Data;
}

void XBpm_detect_Set_regs_3(XBpm_detect *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBpm_detect_WriteReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_3_DATA, Data);
}

u32 XBpm_detect_Get_regs_3(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_3_DATA);
    return Data;
}

void XBpm_detect_Set_regs_4(XBpm_detect *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBpm_detect_WriteReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_4_DATA, Data);
}

u32 XBpm_detect_Get_regs_4(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_4_DATA);
    return Data;
}

void XBpm_detect_Set_regs_5(XBpm_detect *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBpm_detect_WriteReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_5_DATA, Data);
}

u32 XBpm_detect_Get_regs_5(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_5_DATA);
    return Data;
}

u32 XBpm_detect_Get_regs_6(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_6_DATA);
    return Data;
}

u32 XBpm_detect_Get_regs_6_vld(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_6_CTRL);
    return Data & 0x1;
}

u32 XBpm_detect_Get_regs_7(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_7_DATA);
    return Data;
}

u32 XBpm_detect_Get_regs_7_vld(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_7_CTRL);
    return Data & 0x1;
}

u32 XBpm_detect_Get_regs_8(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_8_DATA);
    return Data;
}

u32 XBpm_detect_Get_regs_8_vld(XBpm_detect *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBpm_detect_ReadReg(InstancePtr->Ctrl_BaseAddress, XBPM_DETECT_CTRL_ADDR_REGS_8_CTRL);
    return Data & 0x1;
}

