// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XBPM_DETECT_H
#define XBPM_DETECT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xbpm_detect_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XBpm_detect_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XBpm_detect;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBpm_detect_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBpm_detect_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBpm_detect_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBpm_detect_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XBpm_detect_Initialize(XBpm_detect *InstancePtr, UINTPTR BaseAddress);
XBpm_detect_Config* XBpm_detect_LookupConfig(UINTPTR BaseAddress);
#else
int XBpm_detect_Initialize(XBpm_detect *InstancePtr, u16 DeviceId);
XBpm_detect_Config* XBpm_detect_LookupConfig(u16 DeviceId);
#endif
int XBpm_detect_CfgInitialize(XBpm_detect *InstancePtr, XBpm_detect_Config *ConfigPtr);
#else
int XBpm_detect_Initialize(XBpm_detect *InstancePtr, const char* InstanceName);
int XBpm_detect_Release(XBpm_detect *InstancePtr);
#endif


void XBpm_detect_Set_regs_0(XBpm_detect *InstancePtr, u32 Data);
u32 XBpm_detect_Get_regs_0(XBpm_detect *InstancePtr);
void XBpm_detect_Set_regs_1(XBpm_detect *InstancePtr, u32 Data);
u32 XBpm_detect_Get_regs_1(XBpm_detect *InstancePtr);
void XBpm_detect_Set_regs_2(XBpm_detect *InstancePtr, u32 Data);
u32 XBpm_detect_Get_regs_2(XBpm_detect *InstancePtr);
void XBpm_detect_Set_regs_3(XBpm_detect *InstancePtr, u32 Data);
u32 XBpm_detect_Get_regs_3(XBpm_detect *InstancePtr);
void XBpm_detect_Set_regs_4(XBpm_detect *InstancePtr, u32 Data);
u32 XBpm_detect_Get_regs_4(XBpm_detect *InstancePtr);
void XBpm_detect_Set_regs_5(XBpm_detect *InstancePtr, u32 Data);
u32 XBpm_detect_Get_regs_5(XBpm_detect *InstancePtr);
u32 XBpm_detect_Get_regs_6(XBpm_detect *InstancePtr);
u32 XBpm_detect_Get_regs_6_vld(XBpm_detect *InstancePtr);
u32 XBpm_detect_Get_regs_7(XBpm_detect *InstancePtr);
u32 XBpm_detect_Get_regs_7_vld(XBpm_detect *InstancePtr);
u32 XBpm_detect_Get_regs_8(XBpm_detect *InstancePtr);
u32 XBpm_detect_Get_regs_8_vld(XBpm_detect *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
